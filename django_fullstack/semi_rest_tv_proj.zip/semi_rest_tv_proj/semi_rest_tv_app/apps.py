from django.apps import AppConfig


class SemiRestTvAppConfig(AppConfig):
    name = 'semi_rest_tv_app'
