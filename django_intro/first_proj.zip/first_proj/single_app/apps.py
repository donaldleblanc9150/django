from django.apps import AppConfig


class SingleAppConfig(AppConfig):
    name = 'single_app'
