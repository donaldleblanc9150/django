from django.urls import path
from . import views

urlpatterns = [
    path("/blogs/<number>/delete", views.destroy),
    path("<number>/edit", views.edit),
    path("/blogs/<number>", views.show),
    path("create", views.create),
    path("new", views.new),
    path("", views.index),
]
