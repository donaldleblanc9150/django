from django.apps import AppConfig


class BlogsAppConfig(AppConfig):
    name = 'blogs_app'
