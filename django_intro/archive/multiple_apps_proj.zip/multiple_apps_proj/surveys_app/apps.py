from django.apps import AppConfig


class SurveysAppConfig(AppConfig):
    name = 'surveys_app'
